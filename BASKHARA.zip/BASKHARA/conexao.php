<?php

function connect_db(){
$conn = mysqli_connect('localhost', 'root', '', 'bd_locadora');

}




?>