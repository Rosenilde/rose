<?php

include 'function.php';

$a = (int)$_POST['a'];
$b = (int)$_POST['b'];
$c = (int)$_POST['c'];

$delta_valor = calc_delta($a, $b, $c);

var_dump($a);
var_dump($b);
var_dump($c);
var_dump($delta_valor);

function calc_delta($a, $b, $c)

{


$delta = ($b * $b) - (4 * $a * $c);
if($delta < 0){
    $resultado = $delta;
} else {
    $resultado = 'NAO EXISTE';
}



return($resultado);
}

function x1($a,$b,$c,$delta)
{
x1(-$b + sqrt($delta)) / (2 * $a);

return $x1;

function x2($a,$b,$c,$delta)
{
    if($delta == 0) { 
        $x2= NULL;
    } else {
x2(-$b - sqrt($delta)) / (2 * $a);
    }
return $x2;
}
$delta = calc_delta($a,$b,$c);

if($delta ==false){

    exit("delta negativo");
} elseif ($delta == 0) {
    echo 'delta = 0 , somente uma raiz é possível';
} 
$x1 = x1($a,$b,$c,$delta); 
$x2 = x2($a,$b,$c,$delta); 




$x1 = (-$b + sqrt(calc_delta($a, $b, $c))) / (2 * $a);
$x2 = (-$b - sqrt(calc_delta($a, $b, $c))) / (2 * $a);

$delta = calc_delta($a, $b, $c);


function get_insert_sql($a, $b, $c, $delta, $x1, $x2) {

$query = "insert into formula (a, b, c, delta, x1, x2) values ('$a', '$b', '$c', '$deltavalor', '$x1','$x2')";
return($query);
}

$conn = mysqli_connect('localhost' , 'root' , '' , 'Baskhara');

$result = mysqli_query($conn, $query);

var_dump($result);





?>