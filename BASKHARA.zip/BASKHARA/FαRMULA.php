<!DOCTYPE html>
<html lang="en" dir="ltr">


 <head>
     <meta charset="utf-8">
  <title>Cálculo de Baskhara</title>
 </head>
 <body>
     <form class="" action="Backend.php" method="post">

     <label for="a">Digite o primeiro número(a)</label>
     <input type="text" name="a" value="">
<br>
     <label for="b">Digite o segundo número (b)</label>
     <input type="text" name="b" value="">
<br>

     <label for="c">Digite o terceiro número(c)</label>
     <input type="text" name="c" value="">
<br>
<input type="submit" name="" value="Enviar">
     </form>
 </body>
</html>